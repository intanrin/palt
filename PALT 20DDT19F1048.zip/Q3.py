with open('emailaddress.txt') as f:
    contents = f.read()
    print(contents)