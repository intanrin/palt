from tkinter import *
    
window = Tk()
window.title("GUI Example")
window.geometry("200x200")
window.config(padx=50,pady=50)

userInput = True
def changedText():
    global userInput
    if userInput:
        lbltext["text"] = "I have been changed"
        userInput = False
    else:
        lbltext["text"] = "Change Text"
        userInput = True
        
lbltext = Label(text="Changed Text")
btnChangedText = Button(text="Change Text",command=changedText)
lbltext.grid(row=4,column=1)
btnChangedText.grid(row=3,column=1)
window.mainloop()