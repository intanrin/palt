password = 12345
max_attempt = 5

i = 0

while i< max_attempt:
    guess = int(input('Enter password: '))
    i += 1
    if guess == password:
        print('You are logged in to the system!')
        break

else:
    print('You are blocked of the system')